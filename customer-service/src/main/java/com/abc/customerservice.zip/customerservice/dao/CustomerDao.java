package com.abc.customerservice.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.abc.customerservice.entity.Customer;


public interface CustomerDao extends JpaRepository<Customer,Integer> {

}
